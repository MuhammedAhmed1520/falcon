<?php
/**
 * Created by PhpStorm.
 * User: Hammad
 * Date: 2/21/2019
 * Time: 3:54 PM
 */
return [
    'violation_statistics'=>'Violation Statistics',
    'violation_description'=>'violation Description',
    'violation_number'=>'Violation Number',
    'violation_cost'=>'Violation Cost',
    'best_officers'=>'Violation Best Officers',
    'violation_paid'=>'Violation Paid',
    'violation_monthly'=>'Violation Current Year',
    'violation_yearly'=>'Violation Other Years',
    'top_five_subjects'=>'Top 5 Subjects',
    'title1'=>'title 1',
    'title2'=>'title 2',
    'title3'=>'title 3',
    'title4'=>'title 4',
    'title5'=>'title 5',
    'tender_companies'=>'tender companies',
    'tender_monthly'=>'Tender Monthly In Year',

    'day'=>'Day',
    'week'=>'week',
    'month'=>'month',
    '3-month'=>'3 months',
];
