<?php
 return [
     //Setting
     'certificate_reviewing_app_time_en' => 'Certificate Reviewing App Time en',
     'certificate_reviewing_app_time_ar' => 'Certificate Reviewing App Time ar',
     'certificate_recieving_time_en' => 'Certificate Receiving Time en',
     'certificate_recieving_time_ar' => 'Certificate Receiving Time ar',
     'certificate_manager_name_en' => 'Certificate Manager Name en',
     'certificate_manager_name_ar' => 'Certificate Manager Name ar',
     'certificate_manager_title_en' => 'Certificate Manager Title en',
     'certificate_manager_title_ar' => 'Certificate Manager Title ar',
     'certificate_payment_value' => 'Certificate Payment Value',
     'whatsapp' => 'WhatsApp',

     'communication_name' => 'Head of Environmental Communications and Violations Section',
     'director_name' => 'Director of Environmental Compliance Department',
     'technical_name' => 'Deputy Director General for Technical Affairs',
     
     'front_about_epa'=>'front_about_epa',
     'front_eservices'=>'front_eservices',
     'front_manages'=>'front_manages',
     'front_projects'=>'front_projects',
     'front_news'=>'front_news',
     'front_liberary'=>'front_liberary',
     'front_instagram'=>'front_instagram',
     'front_facebook'=>'front_facebook',
     'front_twitter'=>'front_twitter',
     'front_youtube'=>'front_youtube',
     'front_home'=>'front_home',
     'front_contact'=>'front_contact',
 ];