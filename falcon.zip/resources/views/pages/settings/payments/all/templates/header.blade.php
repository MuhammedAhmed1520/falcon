<div class="col-md-12">
    <div class="header-toggle">
        <div class="hamburger-container menu">
            <div class="hamburger-icon top"></div>
            <div class="hamburger-icon mid"></div>
            <div class="hamburger-icon bottom"></div>
        </div>
    </div>

</div>