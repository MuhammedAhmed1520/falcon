<!-- Fonts -->
<link href="{{asset('front_assets/fonts/font-roboto/font-roboto.css')}}" rel="stylesheet">
<link href="{{asset('front_assets/fonts/font-montserrat/font-montserrat.css')}}" rel="stylesheet">
<link href="{{asset('front_assets/fonts/font-playfair/font-playfair.css')}}" rel="stylesheet">
<link href="{{asset('front_assets/fonts/font-feather/font-feather.css')}}" rel="stylesheet" type="text/css">

<!-- Stylesheets -->
<link href="{{asset('front_assets/css/reset.css')}}" rel="stylesheet" type="text/css">
<link href="{{asset('front_assets/css/bulma.min.css')}}" rel="stylesheet" type="text/css">
<link href="{{asset('front_assets/css/bulma-rtl.min.css')}}" rel="stylesheet" type="text/css">
<link href="{{asset('front_assets/css/animate.css')}}" rel="stylesheet" type="text/css">
<link href="{{asset('front_assets/css/jquery.notify.css')}}" rel="stylesheet" type="text/css">
<link href="{{asset('front_assets/css/styles.css')}}" rel="stylesheet" type="text/css">
<link href="{{asset('front_assets/css/ar.css')}}" rel="stylesheet" type="text/css">