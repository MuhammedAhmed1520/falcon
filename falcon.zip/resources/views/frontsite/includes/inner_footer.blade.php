<div class="text-center" style="color: #c9ef3e;background-color: #151517;text-align: center;padding: 15px;font-size: 16px;">
    <h4>www.epa.org.kw - all rights reserved - 2020</h4>
</div>
