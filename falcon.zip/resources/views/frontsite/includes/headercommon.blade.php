<div class="header">
    <div class="header-fixed" style="background: #1e1f21;padding: 20px 0;">
        <div class="container">
            <div class="columns is-mobile is-vcentered">
                <div class="column">
                    <a href="javascript:;" class="burger-menu"><i class="icon icon-menu"></i></a>
                    <div class="navigation">
                        <a href="javascript:;" class="burger-menu"><i class="icon icon-menu"></i></a>

                        <ul class="list-inline">
                            <li>
                                <a href="{{route('frontIndex')}}">
                                    <img src="{{asset('assets/images/logo.png')}}"
                                         style="width: 70px">
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="column is-narrow logo">
                    <!--<a href="/"><img src="front_assets/images/logo-alt.png" alt="logo" width="50"></a>-->
                </div>
                <div class="column has-text-left">
                    <ul class="details list-inline">
                        <li><a href="">تسجيل الدخول <i class="icon icon-log-in"></i></a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>