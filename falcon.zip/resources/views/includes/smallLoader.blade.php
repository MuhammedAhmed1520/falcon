<div class="window-loader p-1">
    <div class="m-loader m-loader--info m-loader--right">
    <span>please wait ...</span>

    </div>
</div>