<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <form action="">
                <div class="bg-gray mb-2 p-1">
                    <div class="row">
                        <div class="col-md-6">
                            <b>{{__('office_agent.company_name')}}</b>
                            <select class="form-control" name="office_agent_id">
                                @foreach($officeAgents as $officeAgent)
                                    <option value="{{$officeAgent->id}}"
                                        @if($officeAgent->id == request()->get('office_agent_id')) selected @endif
                                    >{{$officeAgent->office_name_ar}}</option>
                                @endforeach
                            </select>
                        </div> 
                        <div class="col-md-12 text-left mt-2 mb-2">
                            <div class="btn-group">
                                <button type="submit" class="btn btn-sm btn-info m-0">
                                    {{__('violation.filter')}}
                                </button> 
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
        <div class="col-md-12">
            <table class="table table-bordered" id="data_table">
                <thead>
                <tr>
                    <th>{{__('office_agent.status')}}</th>
                    <th>{{__('office_agent.date')}}</th> 
                </tr>
                </thead>
                <tbody>
                @if($office_agent_updated)
                    <tr>
                        <td>تاريخ اخر تحديث</td>
                        <td>{{$office_agent_updated['last_updated_date'] ?? ''}}</td> 
                    </tr>
                    <tr>
                       <td>تاريخ اخر تحديث لبيانات الشركة</td>
                        <td>{{$office_agent_updated['entities']['office_agent'] ?? ''}}</td> 
                    </tr> 
                    <tr>
                        <td>تاريخ اخر تحديث لعناوين الفروع الاخري</td>
                        <td>{{$office_agent_updated['entities']['addresses'] ?? ''}}</td> 
                    </tr> 
                    <tr>
                        <td>تاريخ اخر تحديث للمرفقات</td>
                        <td>{{$office_agent_updated['entities']['attachments'] ?? ''}}</td> 
                    </tr> 
                    <tr>
                        <td>تاريخ اخر تحديث لبيانات الشركاء</td>
                        <td>{{$office_agent_updated['entities']['office_partners'] ?? ''}}</td> 
                    </tr> 
                    <tr>
                        <td>تاريخ اخر تحديث لمرفقات الموارد البشرية</td>
                        <td>{{$office_agent_updated['entities']['human_resources_attachments'] ?? ''}}</td> 
                    </tr> 
                    <tr>
                        <td>تاريخ اخر تحديث للموارد البشرية</td>
                        <td>{{$office_agent_updated['entities']['human_resources'] ?? ''}}</td> 
                    </tr> 
                    <tr>
                        <td>تاريخ اخر لمرفقات الاجهزة والمعدات</td>
                        <td>{{$office_agent_updated['entities']['devices_attachments'] ?? ''}}</td> 
                    </tr> 
                    <tr>
                        <td>تاريخ اخر تحديث لمرفقات الشركاء</td>
                        <td>{{$office_agent_updated['entities']['office_partners_attachments'] ?? ''}}</td> 
                    </tr> 
                    <tr>
                        <td>تاريخ اخر تحديث للاجهزة والمعدات</td>
                        <td>{{$office_agent_updated['entities']['devices'] ?? ''}}</td> 
                    </tr> 
                    <tr>
                        <td>تاريخ اخر تحديث للدراسات</td>
                        <td>{{$office_agent_updated['entities']['studies'] ?? ''}}</td> 
                    </tr> 
                @endif
                </tbody>
            </table>
        </div>
    </div>
</div>
