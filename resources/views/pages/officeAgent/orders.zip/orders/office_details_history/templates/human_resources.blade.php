<div class="row">
    <div class="col-md-12 mt-3">
        @include('pages.officeAgent.orders.office_details_history.templates.all_employee')
    </div>
</div>
