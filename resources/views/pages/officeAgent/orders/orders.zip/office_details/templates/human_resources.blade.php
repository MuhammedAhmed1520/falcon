<div class="row">
    {{--<div class="col-md-12 mt-1">--}}
        {{--@include('pages.officeAgent.orders.office_details.templates.view_order_data')--}}
    {{--</div>--}}
    {{--<div class="col-md-12 mt-3">--}}
        {{--@include('pages.officeAgent.orders.office_details.templates.edit_employee')--}}
    {{--</div>--}}
    <div class="col-md-12 mt-3">
        @include('pages.officeAgent.orders.office_details.templates.all_employee')
    </div>
</div>
