<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="bg-gray mb-2 p-1">
                <form method="get">
                    <div class="row">
                        <div class="col-md-3">
                            <label>{{__('violation.amount')}}</label>
                            <input name="amount" class="form-control" value="{{request()->amount}}"/>
                        </div>
                        <div class="col-md-2">
                            <label>{{__('violation.status')}}</label>
                            <select name="status" class="form-control">
                                <option value="ALL" @if(\request()->status == "ALL") selected @endif >{{__('violation.ALL')}}</option>
                                <option value="CAPTURED" @if(\request()->status == "CAPTURED") selected @endif >CAPETURED</option>
                                <option value="NOT CAPTURED" @if(\request()->status == "NOT CAPTURED") selected @endif>NOT CAPETURED</option>
                                <option value="CANCELED" @if(\request()->status == "CANCELLED") selected @endif>CANCELLED</option>
                            </select>
                        </div>
                        <div class="col-md-2">
                            <label>{{app()->getLocale() == 'ar' ? 'النوع' : 'Type'}}</label>
                            <select name="type" class="form-control">
                                <option value="ALL">{{__('violation.ALL')}}</option>
                                @foreach($paymentable_types as $paymentable)
                                <option value="{{ str_replace('App\Models\\' , '' , $paymentable) }}" @if(\request()->type == str_replace('App\Models\\' , '' , $paymentable)) selected @endif>{{__('violation.'.str_replace('App\Models\\' , '' , $paymentable))}}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="col-md-2">
                            <label>{{__('violation.paid')}}</label>
                            <select name="payment_type" class="form-control">
                                <option value="ALL" @if(\request()->payment_type == "ALL") selected @endif>{{__('violation.ALL')}}</option>
                                <option value="KNET" @if(\request()->payment_type == "KNET") selected @endif>{{__('violation.online')}}</option>
                                <option value="CASH" @if(\request()->payment_type == "CASH") selected @endif>{{__('violation.offline')}}</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-12 mt-3">
                        <button class="btn btn-primary btn-sm">{{__('violation.filter')}}</button>
                    </div>
                </form>
            </div>
        </div>
        
        <div class="col-md-12">
            <table class="table table-striped table-bordered table-hover" id="data_table" style="width:100%">
                <thead>
                <tr>
                    <th width="50px"></th>
                    <th>{{__('violation.civil_name')}}</th>
                    <th>{{__('violation.email')}}</th>
                    <th>{{__('violation.civil_phone')}}</th>
                    <th>{{__('violation.amount')}}</th>
                    <th>{{__('violation.violation_at')}}</th>
                    <th>{{app()->getLocale() == 'ar' ? 'النوع' : 'Type'}}</th>
                    <th>{{__('violation.paid')}}</th>
                    <th>{{__('violation.status')}}</th>
                </tr>
                </thead>
                <tbody>
                @foreach($payments as $k => $payment)
                    <tr>
                        <td></td>
                        <td>
                            {{$payment->name}}
                        </td>
                        <td>
                            {{$payment->email}}
                        </td>
                        <td>
                            {{$payment->phone}}
                        </td> 
                        <td>
                            {{$payment->cost}}
                        </td>
                        <td>
                            {{$payment->created_at}}
                        </td>
                        <td>
                            {{ str_replace('App\Models\\' , ' ' , $payment->paymentable_type) }}
                        </td>
                        <td>
                            {{(!$payment->knet_data && $payment->status == 1 ) ? 'CASH' : 'KNET'}}
                        </td>
                        
                        <td class="text-center">
                            {!! $payment->status == 0 ?  '<i class="la la-close text-danger"></i>' : '<i class="la la-check text-success"></i>' .' ('. $payment->updated_at .')' !!}
                            @if($payment->knet_data)
                                {{$payment->knet_data->result ?? ''}}  
                                <br>
                                <span class="text-info"> {{$payment->knet_data->tran_id ?? ''}} </span>
                            @endif
                        </td>
                    </tr>
                @endforeach
                </tbody>
            </table>
        </div>
        <div class="col-md-12">
            {{$payments->appends(request()->input())->render("pagination::bootstrap-4")}}
        </div>
    </div>
</div>